# Flappy-Bird
<br>
Flap the bird
<br>
<br>
<img src="/home_screen.png"></img>
<br>
Tap to start game !
<br>
<h3>Game Rules:</h3>
<br>
<img src="/flappy_game.png" style="width: 200px;"></img>
<img src="/game_7.png" style="width: 200px;"></img>
1.Goal is to score as much as posiible.
<br>
2.Tap or press on upper button to make bird move up else it will be falling towards ground.
<br>
3.By each passing pillar your score will be increased by +1.
<br>
4.If the bird hits the ground,pillars or top game ends.
<br>
<h3>Technology:</h3>
Python,Pygame library.
